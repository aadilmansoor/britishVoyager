const productDetails = (page) => {
    window.location.href = `/product/${page}`
}